﻿using Server;

Console.WriteLine("Starting Server");

TCPServer server = new TCPServer(5555);
